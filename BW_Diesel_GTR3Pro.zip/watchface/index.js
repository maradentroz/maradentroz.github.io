﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
	let header_img = ''
	let sky_Animation = ''
	let normal_moon_image_progress_img_level = ''
	let aeon = ''
	let normal_sun_pointer_progress_img_pointer = ''
	let moon_pointer = ''
	let castle_img = ''
	let cauldron_img = ''	
	let cauldron_Animation = ''
	let cboil_Animation = ''
	let witch_Animation = ''
	let coals_Animation = ''
	let normal_sun_icon_img = ''
	let normal_image_img = ''
        let normal_heart_rate_text_text = ''
	let group = '';
	let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
	let normal_wind_text_text_img = ''	
	let normal_wind_direction_progress_img_pointer = ''
	let normal_altimeter_current_text = ''
	let trend_img = ''
	let normal_date_img_date_day = ''
        let normal_step_current_text_font = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
	let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
	let normal_step_jumpable_img_click = ''
	let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
	let normal_anim_h='';
	let normal_anim_h_group='';
	let anim_f=10;
	let fps_s=30;

/********************************
	*	класс AdvancedBarometer		*
	*			   v1.0				*
	*		2025 © leXxiR [4pda]	*
	********************************/
		class AdvancedBarometer {
		  constructor(props = {}) {
			this.props = {
				unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
				show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
				widget: null,												// виджет TEXT для отображения давления
				show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
				time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
				auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
				lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
				...props,
			};

			this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
								['гПа',  'hPa'],			// 1	
							]

			this.last = {
				value: '--',
				trend: '',
			}

			if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
			if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
			if (this.props.auto_update) this.createHandlers();
		  }

		// создание обработчиков автоматического обновления давления
			createHandlers() {
				this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

				this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: ( () => this.update() )
				})
			}
 
		// чтение файла с данными атмосферного давления
			readDataFile() {		
				const file_name_alt = "../../../baro_altim/pressure.dat";
				const [fs_stat, err] = hmFS.stat(file_name_alt);
				if (err == 0) {
				  let file_size = fs_stat.size;
				  const len = file_size / 4;
				  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
				  let array_buffer = new Float32Array(len);
				  hmFS.read(fh, array_buffer.buffer, 0, file_size);
				  hmFS.close(fh);
				  return array_buffer;
				} else {
				  console.log('err:', err)
				}
				return null
			}
				
		// получение последнего значения в массиве данных из файла
			getLastValue(data_array) {
				if(!data_array?.length) return null;
				
				const start = data_array.length - 1;
				let end = start - 30 * 3; // 3 часа
				if(end < 0) end = 0;
				
				for (let i = start; i >= end; i--) {
				  if(data_array[i] != 0) return parseInt(data_array[i] / 100);
				}
				
				return null
			}
		
		// получение изменения давления
			getPressureChange(data_array) {
				if(!data_array?.length) return null;
				const start = data_array.length - 1;
				let end = start - 30 * 3; // 3 часа
				if(end < 0) end = 0;

				let value = data_array[start];

				for (let i = start - 1; i >= end; i--) {
				  let element = data_array[i];
				  if(element != 0) {
					if(Math.abs(value - element) > 75) { // учитываем только если разница больше 0,75 hPa ~ 1 мм рт.ст.
					  value = value - element;
					  return value;
					}
				  }
				}
				return null
			}

		// получить текущее значения  давления и тренда
			getPressureAndTrend(){
				const data_array = this.readDataFile();
				const value = this.getLastValue(data_array);

				let trend = ''; //	"•"
				const pressureChange = this.getPressureChange(data_array);
				if (pressureChange < 0) trend = "↓";
				else if (pressureChange > 0) trend = "↑";

				return {value, trend}
			}


		// установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
			setUnits(unit_index) {
				if(!isFinite(unit_index)) return
				this.props.unit_index = unit_index == 1 ? 1 : 0;
				hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
				if (this.props.widget) this.updateWidget();
			}

		// переключить единицы измерения на следующие по кругу
			toggleUnits(show_toast = this.props.show_toast) {
				const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
				this.setUnits(newIndex);
				if (show_toast) hmUI.showToast({text: this.unit});
			}

		// обновить показания давления и виджет
			update() {
				const {value, trend}  = this.getPressureAndTrend();
				if (value != this.last.value){
					this.last.value = value;
					this.last.trend = trend;
					if (this.props.widget) this.updateWidget();
				}
			}

		// обновить виджет
			updateWidget() {
				let str = this.pressure;
				if (this.props.show_trend) str += ` ${this.last.trend}`;
				this.props.widget.setProperty(hmUI.prop.TEXT, str);
				
			}

		// получить текущее значение давление в мм рт. ст.
			get mmHg() {
				let v = this.last.value;
				if (!(v)) return '--'
				else v *= 0.750064;
				return Math.round(v).toString();
			}

		// получить текущее значение давление в гПа
			get hPa() {
				let v = this.last.value;
				if (!(v)) return '--'
				return this.last.value
			}

		// получить давление в текущих единицах измерения
			get pressure() {
				if (this.props.unit_index == 0) return this.mmHg
				else return this.hPa
			}

		// получить название текущей единицы измерения
			get unit() {
				return this.unitStr[this.props.unit_index][this.props.lang]
			}

		// получить индекс текущей единицы измерения
			get unit_index() {
				return this.props.unit_index
			}

		// получить тренд
			get trend() {
				return this.last.trend
			}

		// удалить
		  delete() {
			this.props = null;
			this.last = null;
			this.unitStr = null;
			if (this.widgetDelegate) {
				hmUI.deleteWidget(this.widgetDelegate);
				this.widgetDelegate = null;
			}
		  }

		}


const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();

		
let sleep_time_txt = ''
		
		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		//let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();

		let sleepStageArray = sleep.getSleepStageData();
		const modelData = sleep.getSleepStageModel();
		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepStageArray = sleep.getSleepStageData();
			//sleepInfo = sleep.getBasicInfo();
			
		let wakeTime = 0;
		sleepStageArray = sleep.getSleepStageData();
			
			for (let i = 0; i < sleepStageArray.length; i++) {
			  let data = sleepStageArray[i];
			  if (data.model == modelData.WAKE_STAGE){
					wakeTime += data.stop + 1 - data.start;
			  }

			}
			
			sleepTotalTime -= wakeTime;

		sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + '.' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       
        }


		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);

		let sunText = ''
		let lastSunTime = ''
		
		
		function getSunTime(){
			let sunDataText = '--';
			let weatherData = weather.getForecastWeather();
			let sunData = weatherData.tideData;

			if (sunData.count > 0){
				let today = sunData.data[0];
				let sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				let sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
				
				let curMins = curTime.hour * 60 + curTime.minute;
				let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
				
				if(isDayNow){
					sunDataText = `${today.sunset.hour.toString().padStart(2, "0")}.${today.sunset.minute.toString().padStart(2, "0")}`;

				} else {
					let hh = (curMins < sunriseMins) ? today.sunrise.hour : sunData.data[1].sunrise.hour;
					let mm = (curMins < sunriseMins) ? today.sunrise.minute : sunData.data[1].sunrise.minute;
					sunDataText = `${hh.toString().padStart(2, "0")}.${mm.toString().padStart(2, "0")}`;
				}
			}

			return sunDataText
		}

		function updateSun(){
			const val = getSunTime();
			if (val != lastSunTime){
				lastSunTime = val;
				sunText.setProperty(hmUI.prop.TEXT, val);
							}
		}

	
//------------------------ замок -----------------------------------

		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			// время восхода
		let sunsetMins_def = 20 * 60;			// и заката по умолчанию
		let curMins = '';
			  
		
		function moveCastle() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isMorningNow = curMins >= sunriseMins - 60 && curMins < sunriseMins;
			let isDayNow = curMins >= sunriseMins && curMins < sunsetMins - 60;
			let isEveningNow = curMins >= sunsetMins - 60 && curMins < sunsetMins;
			let isNightNow = !isMorningNow && !isDayNow && !isEveningNow;
						
	
	if (isMorningNow)  {

			sky_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
			sky_Animation.setProperty(hmUI.prop.VISIBLE, false);
			cboil_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
			cboil_Animation.setProperty(hmUI.prop.VISIBLE, false);
			cauldron_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
			cauldron_Animation.setProperty(hmUI.prop.VISIBLE, false);
			coals_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
			coals_Animation.setProperty(hmUI.prop.VISIBLE, true);
			header_img.setProperty(hmUI.prop.SRC, 'header_m.png');
			castle_img.setProperty(hmUI.prop.SRC, 'castle_m.png');
			/*castle_img.setProperty(hmUI.prop.X, 168);
			castle_img.setProperty(hmUI.prop.Y, 5);*/
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true)
			moon_pointer.setProperty(hmUI.prop.VISIBLE, false);
			cauldron_img.setProperty(hmUI.prop.VISIBLE, false);
			aeon.setProperty(hmUI.prop.VISIBLE, true);


	} if (isDayNow) {
				sky_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				sky_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cboil_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				cboil_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cauldron_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				cauldron_Animation.setProperty(hmUI.prop.VISIBLE, false);
				header_img.setProperty(hmUI.prop.SRC, 'header_d.png');
				castle_img.setProperty(hmUI.prop.SRC, 'castle_d.png');
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				moon_pointer.setProperty(hmUI.prop.VISIBLE, false);
				coals_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				coals_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cauldron_img.setProperty(hmUI.prop.VISIBLE, false);
				aeon.setProperty(hmUI.prop.VISIBLE, false);

	} if (isEveningNow) {
				sky_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				sky_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cboil_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				cboil_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cauldron_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				cauldron_Animation.setProperty(hmUI.prop.VISIBLE, false);
				cauldron_img.setProperty(hmUI.prop.VISIBLE, true);
				header_img.setProperty(hmUI.prop.SRC, 'header_e.png');
				castle_img.setProperty(hmUI.prop.SRC, 'castle_e.png');
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				moon_pointer.setProperty(hmUI.prop.VISIBLE, false);
				coals_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				coals_Animation.setProperty(hmUI.prop.VISIBLE, false);
				aeon.setProperty(hmUI.prop.VISIBLE, false);


 	} if (isNightNow) {	
				cauldron_img.setProperty(hmUI.prop.VISIBLE, false);
				sky_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
				sky_Animation.setProperty(hmUI.prop.VISIBLE, true);
				castle_img.setProperty(hmUI.prop.SRC, 'castle_n.png');
				/*castle_img.setProperty(hmUI.prop.X, 168);
				castle_img.setProperty(hmUI.prop.Y, 5);*/
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				coals_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
				coals_Animation.setProperty(hmUI.prop.VISIBLE, false);
				aeon.setProperty(hmUI.prop.VISIBLE, false);

	}    	 
    }      
               

        function cauldronTime(){
			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}
			
			curMins = curTime.hour * 60 + curTime.minute;
			let isCauldronNow = curMins >= sunsetMins && curMins < sunsetMins + 120;
			let isPartyNow = curMins >= sunsetMins + 120 || curMins < sunriseMins - 60;
			let witch = curMins >= sunsetMins + 115 && curMins < sunsetMins + 120;

if (isCauldronNow){
cauldron_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
cauldron_Animation.setProperty(hmUI.prop.VISIBLE, true);
cboil_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
cboil_Animation.setProperty(hmUI.prop.VISIBLE, false);

						}

if (isPartyNow){
cauldron_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
cauldron_Animation.setProperty(hmUI.prop.VISIBLE, false);
cboil_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
cboil_Animation.setProperty(hmUI.prop.VISIBLE, true);
	}

if (witch){
witch_Animation.setProperty(hmUI.prop.VISIBLE, true);
witch_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
	} else {
witch_Animation.setProperty(hmUI.prop.VISIBLE, false);
witch_Animation.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
	}
}	


		
//----------------------------------------------------------- \\

		function moveMoon() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isNightNow = (curMins < sunriseMins - 60) || (curMins >= sunsetMins + 120);
						
			if (isNightNow){
				let nightDuration = 24 * 60 - (sunsetMins - sunriseMins) - 180;
				let elapsedMins = curMins - (sunsetMins + 120);			// прошло минут с заката
				if (curMins < sunriseMins) elapsedMins += 24 * 60		// если начались новые сутки	
				let moonAngle = (elapsedMins / nightDuration) * 60;
				moon_pointer.setProperty(hmUI.prop.VISIBLE, true);
				moon_pointer.setProperty(hmUI.prop.ANGLE, moonAngle);
			}
		}

//------------------Иконки ночные---------------------

		let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png", 
                     "w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png", 
                     "w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_2n.png","w_3n.png","w_6n.png"]
				
		let isDayIcons = true;
               //Здесь перечислены индексы иконок, которые нужно менять на ночные и обратно. Если у вас они другие, необходимо отредактировать этот список.
		let wiReplacement = [0, 1, 2, 3, 6];		// индексы иконок для замены день-ночь

		
		function autoToggleWeatherIcons() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
					}
					isDayIcons = true;
				}
			} else {
				if(isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
					}
					isDayIcons = false;
				}
			}
		}

        //dynamic modify end


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Square 721 Bold Extended BT.ttf; FontSize: 11
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 229,
              h: 16,
              text_size: 11,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Square 721 Bold Extended BT.ttf',
              color: 0xFF06C4C7,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,			
              y: 206,
	  font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
 	      padding: false,
              h_space: -1,
	      dot_image: 'dots.png',
	      align_h: hmUI.align.CENTER_H,
	      show_level: hmUI.show_level.ONLY_NORMAL,
            });

sunText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 347,
font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
              text: getSunTime(),
              padding: false,
              h_space: -1,
	      dot_image: 'dots.png',
	      align_h: hmUI.align.CENTER_H,
	      show_level: hmUI.show_level.ONLY_NORMAL,
            });

header_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 0,
	      w: 480,
	      h: 480,
              src: 'header_m.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  

sky_Animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
 x: 156,
  y: 0,
      anim_path: "anim",
      anim_prefix: "sky",
      anim_ext: "png",
      anim_fps: 1,
      anim_size: 18,
      repeat_count: 0,
      anim_repeat: true,
      anim_status: hmUI.anim_status.STOP,
      show_level: hmUI.show_level.ONLY_NORMAL,
      });

normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 278,
              y: 5,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

aeon = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 6,
	      w: 480,
	      h: 480,
              src: 'aeon.png',
	      alpha: 255,
	      visible: false,
	      show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun.png',
              center_x: 240,
              center_y: 190,
              x: 48,
              y: 190,
              start_angle: -17,
              end_angle: 38,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

moon_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              src: 'moon.png',
              x: 0,
              y: 0,
			  w: 480,
			  h: 480,
              angle: 0,
			  pos_x: 142,
			  pos_y: 20,
			  center_x: 240,
			  center_y: 195,
			  show_level: hmUI.show_level.ONLY_NORMAL,
            });

castle_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 5,
	      w: 480,
	      h: 480,
              src: 'castle_m.png',
	      show_level: hmUI.show_level.ONLY_NORMAL,
            });

cauldron_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 265,
              y: 40,
	      src: 'cauldron.png',
	      visible: false,
	      show_level: hmUI.show_level.ONLY_NORMAL,
            });

cauldron_Animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
 x: 265,
  y: 40,
      anim_path: "anim",
      anim_prefix: "c",
      anim_ext: "png",
      anim_fps: 2,
      anim_size: 10,
      repeat_count: 0,
      anim_repeat: true,
      anim_status: hmUI.anim_status.STOP,
      show_level: hmUI.show_level.ONLY_NORMAL,
      });

cboil_Animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
 x: 265,
  y: 40,
      anim_path: "anim",
      anim_prefix: "cb",
      anim_ext: "png",
      anim_fps: 4,
      anim_size: 18,
      repeat_count: 0,
      anim_repeat: true,
      anim_status: hmUI.anim_status.STOP,
      show_level: hmUI.show_level.ONLY_NORMAL,
      });

witch_Animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
 x: 168,
  y: 5,
      anim_path: "anim",
      anim_prefix: "w",
      anim_ext: "png",
      anim_fps: 2,
      anim_size: 45,
      repeat_count: 1,
      anim_repeat: false,
      anim_status: hmUI.anim_status.STOP,
      show_level: hmUI.show_level.ONLY_NORMAL,
      });

coals_Animation = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
 x: 265,
  y: 40,
      anim_path: "anim",
      anim_prefix: "coals",
      anim_ext: "png",
      anim_fps: 2,
      anim_size: 15,
      repeat_count: 0,
      anim_repeat: true,
      anim_status: hmUI.anim_status.STOP,
      show_level: hmUI.show_level.ONLY_NORMAL,
      });

normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 15,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 176,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 258,
              font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

group = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.LAST, function() {
		      	  animation_call()
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 377,
              y: 272,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 365,
              y: 187,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            autoToggleWeatherIcons();

	    normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 256,
              y: 213,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 159,
              y: 247,
              w: 30,
              h: 30,
              text_size: 11,
              char_space: 0,
              font: 'fonts/Square 721 Bold Extended BT.ttf',
              color: 0xFFFC032F,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 126,
              y: 247,
              w: 30,
              h: 30,
              text_size: 11,
              char_space: 0,
              font: 'fonts/Square 721 Bold Extended BT.ttf',
              color: 0xFF0080FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 142,
              y: 205,
              w: 30,
              h: 30,
              text_size: 11,
              char_space: 0,
              font: 'fonts/Square 721 Bold Extended BT.ttf',
              color: 0xFF06C4C7,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 223,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_wind_direction_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.2.png',
              center_x: 156,
              center_y: 239,
              x: 8,
              y: 25,
              start_angle: -45,
              end_angle: 315,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

normal_altimeter_current_text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 332,
              font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
              padding: false,
              h_space: 0,
	      w: 60,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// экземпляр класса
			const barometer = new AdvancedBarometer({
				widget: normal_altimeter_current_text,
			});

trend_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 332,
	src: 'up.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 349,
              day_startY: 232,
              day_sc_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              day_tc_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              day_en_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

const step = hmSensor.createSensor(hmSensor.id.STEP);
step.addEventListener(hmSensor.event.CHANGE, function() {
stepColor();            
});
            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 137,
              w: 150,
              h: 30,
              font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.1.png',
              center_x: 239,
              center_y: 158,
              x: 8,
              y: 40,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0007.2.png',
              center_x: 240,
              center_y: 322,
              x: 10,
              y: 40,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 32,
              minute_posY: 176,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 45,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

	   normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 120,
              w: 75,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 320,
              w: 53,
              h: 52,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 373,
              w: 59,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 373,
              w: 59,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 182,
              w: 43,
              h: 34,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 228,
              w: 36,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 253,
              w: 36,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 126,
              y: 218,
              w: 62,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 181,
              w: 42,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            
let anim_sz=10;
			
			
			function animation_call(){
				if(typeof normal_anim_h !== 'string'){
					hmUI.deleteWidget(normal_anim_h);
				}	
							
				if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {

					if(!isNaN(heart_rate.last) && heart_rate.last > 10){
						anim_sz=Math.ceil(30/(heart_rate.last/60));
					}else{
						anim_sz=20;
					}

					normal_anim_h = group.createWidget(hmUI.widget.IMG_ANIM, {
						  anim_path: 'animation',
						  anim_prefix: 'heart',
						  anim_ext: 'png',
						  anim_fps: Math.ceil(heart_rate.last/10),//6,//30,
						  repeat_count: 0,
						  anim_size: 6,//anim_sz,
						  anim_status: hmUI.anim_status.START,
						  anim_repeat: true,
						  x: 85,//0,
						  y: 280,//0,
						  show_level: hmUI.show_level.ONLY_NORMAL,
						});	
//					normal_anim_h.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);					
				}
			}

function stepColor() {
      let curSteps = step.current;
let targetSteps = step.target;
let isGoal = curSteps > targetSteps

if (isGoal){
normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
	 x: 165,
              y: 137,
              w: 150,
              h: 30,
              font_array: ["y_0.png","y_1.png","y_2.png","y_3.png","y_4.png","y_5.png","y_6.png","y_7.png","y_8.png","y_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
		}
if (!isGoal){
normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
	 x: 165,
              y: 137,
              w: 150,
              h: 30,
              font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
	      padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
		});
	} 
}



curTime.addEventListener(curTime.event.MINUTEEND, function () {
				updateSun();
				moveCastle();
				moveMoon();
				cauldronTime();
			});


                        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
			updateSleepInfo();
               		   animation_call();
				updateSun();
 				moveCastle();
				moveMoon();
				cauldronTime();
				stepColor();
				autoToggleWeatherIcons();
				if (barometer.trend == '↓') trend_img.setProperty(hmUI.prop.SRC, 'down.png');
	else if (barometer.trend == '↑') trend_img.setProperty(hmUI.prop.SRC, 'up.png');
	else if (barometer.trend == '') trend_img.setProperty(hmUI.prop.SRC, 'null.png');
				console.log('resume_call()');
                scale_call();
              }),
		
            }); 


            //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}